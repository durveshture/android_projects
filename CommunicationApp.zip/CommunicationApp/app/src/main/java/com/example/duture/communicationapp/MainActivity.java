package com.example.duture.communicationapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etPhoneNumber, etLink, etNumber, etPhoneMessage, etEmailAddress, etEmailSubject, etEmailMessage;
    Button btnVisit, btnCall, btnSendSms, btnSendMail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etLink = findViewById(R.id.etLink);
        etNumber = findViewById(R.id.etNumber);
        etPhoneMessage = findViewById(R.id.etPhoneMessage);
        etEmailAddress = findViewById(R.id.etEmailAddress);
        etEmailSubject = findViewById(R.id.etEmailSubject);
        etEmailMessage = findViewById(R.id.etEmailMessage);
        btnVisit = findViewById(R.id.btnVisit);
        btnCall = findViewById(R.id.btnCall);
        btnSendSms = findViewById(R.id.btnSendSms);
        btnSendMail = findViewById(R.id.btnSendMail);

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etPhoneNumber.getText().toString().length() < 10) {
                    etPhoneNumber.setError("Enter valid phone number");
                    etPhoneNumber.requestFocus();
                    return;
                }

                String n = etPhoneNumber.getText().toString();
                Intent c = new Intent(Intent.ACTION_CALL);
                c.setData(Uri.parse("tel:" + n));
                startActivity(c);
            }
        });

        btnVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etLink.getText().toString().length() == 0) {
                    etLink.setError("Web Link Empty");
                    etLink.requestFocus();
                    return;
                }

                String url = etLink.getText().toString();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("http:" + url));
                Intent c = Intent.createChooser(i, "View Web Page");
                startActivity(i);
            }
        });

        btnSendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etNumber.getText().toString().length() < 10) {
                    etNumber.setError("Enter valid phone number");
                    etNumber.requestFocus();
                    return;
                }

                if (etPhoneMessage.getText().toString().equals("")) {
                    etPhoneMessage.setError("Message should not be blank");
                    etPhoneMessage.requestFocus();
                    return;
                }

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("sms:" + etNumber.getText().toString()));
                intent.putExtra("sms_body", etPhoneMessage.getText().toString());
                startActivity(intent);
            }
        });

        btnSendMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (etEmailSubject.getText().toString().equals("")) {
                    etEmailSubject.setError("Subject Empty");
                    etEmailSubject.requestFocus();
                    return;
                }

                if (etEmailMessage.getText().toString().equals("")) {
                    etEmailMessage.setError("Content Empty");
                    etEmailMessage.requestFocus();
                    return;
                }

                if(!Patterns.EMAIL_ADDRESS.matcher(etEmailAddress.getText().toString()).matches()){
                    etEmailAddress.setError("Invalid Email");
                    etEmailAddress.requestFocus();
                    return;
                }

                Intent emailIntent= new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:"+etEmailAddress.getText().toString()));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT,etEmailSubject.getText().toString());
                emailIntent.putExtra(Intent.EXTRA_TEXT,etEmailMessage.getText().toString());
                startActivity(emailIntent);
            }
        });

    }
}
